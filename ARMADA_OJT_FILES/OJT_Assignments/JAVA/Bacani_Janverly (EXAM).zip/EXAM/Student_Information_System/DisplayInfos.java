interface DisplayInfo {
    void displayInfo();
}