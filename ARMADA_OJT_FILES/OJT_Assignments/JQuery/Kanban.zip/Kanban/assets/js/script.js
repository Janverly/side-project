    $(function() {
        $(".connected").sortable({
            connectWith: ".connected",   // Sort items from one list into another and vice versa, by passing a selector into the connectWith option. The simplest way to do this is to group all related lists with a CSS class, and then pass that class into the sortable function (i.e., connectWith: '.myclass').
            placeholder: "ui-state-highlight"
        }).disableSelection();
    });