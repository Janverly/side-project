$(document).ready(function(){

    const candies = ["candy1.png","candy2.png","candy3.png","candy4.png"];
    const question = "question.png"; 
    const totalPairs = 6; /*12 total kasi pair nga*/
    let flipped = [];

/*  
 * DOCU: Implements a simple memory-based candy matching game using jQuery.
 *       The game generates shuffled pairs of candies, displays them as hidden cards,
 *       and allows users to flip two cards at a time to find matching pairs.
 *       Matched pairs are removed, while unmatched pairs are flipped back.
 *       Includes reset functionality to reload a new shuffled board.
 * 
 * Last Updated: 2026-03-23  
 * Author: Janverly  
 */
    /*shuffled candy pairs*/
    function generatePairs() {
        let pairList = [];
        for(let i = 0; i < totalPairs; i++){
            const candy = candies[i % candies.length];
            pairList.push(candy, candy);
        }
        return pairList.sort(() => Math.random() - 0.5);
    }

    /* columns and rows */
    function loadGame() {
        const pairList = generatePairs();
        $("#game").empty();
        pairList.forEach(c => {
            $("#game").append(`<img src="img/${question}" data-candy="${c}" class="candy">`);
        });
        flipped = [];
    }

    /*card flip*/
    function handleFlip($card) {
        if($card.data("flipped") || flipped.length === 2) return;

        $card.attr("src", "img/" + $card.data("candy")).data("flipped", true);
        flipped.push($card);

        if(flipped.length === 2){
            const [first, second] = flipped;

            if(first.data("candy") === second.data("candy")){
                setTimeout(() => { 
                    first.fadeOut(400, function(){ $(this).remove(); });
                    second.fadeOut(400, function(){ $(this).remove(); });
                }, 300);
            } else {
                setTimeout(() => {
                    first.attr("src", "img/" + question).data("flipped", false);
                    second.attr("src", "img/" + question).data("flipped", false);
                }, 800);
            }

            flipped = [];
        }
    }

    
    loadGame();

    $("#game").on("click", ".candy", function(){ handleFlip($(this)); });
    $("#reset").click(loadGame);

});